import { useState, useEffect, useRef, useCallback } from 'react';

// ── Canvas constants ──────────────────────────────────────────
const S = 8;           // pixel scale (each "pixel" = 8×8 real px)
const GW = 22;         // grid width
const GH = 36;         // grid height
const CX = 11;         // center x column
const SOIL_TOP = 20;   // soil row start
const BASE_Y = SOIL_TOP - 1; // plants grow up from row 19

// ── Color palette ─────────────────────────────────────────────
const BG1 = '#0D0D1A', BG2 = '#111128';
const STAR = '#FFFFFF';
// Soil
const S1 = '#5C3820', S2 = '#4A2E18', S3 = '#3A2010', S4 = '#6B4428';
// Pot rim
const PR = '#E07840', PRL = '#F09060', PRD = '#A05020';
// Pot body
const PB = '#C86030', PBL = '#D87040', PBD = '#904018';
// Pot base
const PA = '#A04820', PAD = '#803818';
// Stems & leaves
const SG = '#2D8B1E', SGD = '#1C5C12';
const LG = '#4CB834', LGL = '#70D050';
// Sunflower
const PY = '#F4C830', PYD = '#C89010';
const FC = '#7A3808', FCL = '#A05010';
// Cactus
const CG = '#308040', CGD = '#1E5028', CGL = '#40A050';
const CSP = '#E0D080';
// Mushroom
const MR = '#D03020', MRD = '#901A10', MRH = '#E04030';
const MSP = '#F0EED8';
const MST = '#D8C898', MSTD = '#B8A878';
// Potato
const P2Y = '#C8A040', P2YD = '#A07828';
// Flower
const FP1 = '#E040A0', FP2 = '#F870C0', FCE = '#FFFE40';

type PT = 'potato' | 'sunflower' | 'cactus' | 'mushroom' | 'flower';

const PLANTS: { id: PT; name: string; emoji: string; color: string; growthTime: number }[] = [
  { id: 'sunflower', name: 'Sunflower', emoji: '🌻', color: '#F4C830', growthTime: 3000 },
  { id: 'potato',    name: 'Potato',    emoji: '🥔', color: '#C8A040', growthTime: 4000 },
  { id: 'cactus',    name: 'Cactus',    emoji: '🌵', color: '#308040', growthTime: 5000 },
  { id: 'mushroom',  name: 'Mushroom',  emoji: '🍄', color: '#D03020', growthTime: 2000 },
  { id: 'flower',    name: 'Flower',    emoji: '🌸', color: '#E040A0', growthTime: 3000 },
];

const STAGE_NAMES = ['Just Planted', 'Sprouting...', 'Growing...', 'Maturing...', 'Fully Grown! 🎉'];

// ── Drawing helpers ───────────────────────────────────────────
const dp = (ctx: CanvasRenderingContext2D, x: number, y: number, col: string, alpha = 1) => {
  if (x < 0 || x >= GW || y < 0 || y >= GH) return;
  const prev = ctx.globalAlpha;
  if (alpha !== 1) ctx.globalAlpha = alpha;
  ctx.fillStyle = col;
  ctx.fillRect(x * S, y * S, S, S);
  if (alpha !== 1) ctx.globalAlpha = prev;
};

// ── Background ────────────────────────────────────────────────
const STARS = [[2,1],[5,3],[9,0],[14,2],[18,1],[20,4],[3,6],[7,5],[16,3],[19,8],[1,4],[12,7]];

const drawBG = (ctx: CanvasRenderingContext2D, t: number) => {
  for (let y = 0; y < GH; y++) {
    for (let x = 0; x < GW; x++) {
      dp(ctx, x, y, y < 18 ? BG1 : BG2);
    }
  }
  STARS.forEach(([sx, sy]) => {
    if (sy < SOIL_TOP) {
      const twinkle = 0.4 + 0.35 * Math.sin(t / 900 + sx * 1.7 + sy);
      dp(ctx, sx, sy, STAR, twinkle);
    }
  });
};

// ── Soil ──────────────────────────────────────────────────────
const drawSoil = (ctx: CanvasRenderingContext2D) => {
  const cols = [S1, S2, S3, S4];
  for (let row = 0; row < 4; row++) {
    for (let x = 2; x <= 19; x++) {
      dp(ctx, x, SOIL_TOP + row, cols[(x * 3 + row * 7) % 4]);
    }
  }
};

// ── Pot ───────────────────────────────────────────────────────
const drawPot = (ctx: CanvasRenderingContext2D) => {
  const py = SOIL_TOP + 4; // row 24

  // Rim (2 rows)
  for (let x = 1; x <= 20; x++) dp(ctx, x, py,     x === 1 || x === 20 ? PRL : PR);
  for (let x = 1; x <= 20; x++) dp(ctx, x, py + 1, PRD);

  // Body (6 rows, tapering)
  const bodyRanges: [number, number][] = [
    [2, 19], [2, 19],
    [3, 18], [3, 18],
    [4, 17], [4, 17],
  ];
  bodyRanges.forEach(([l, r], i) => {
    for (let x = l; x <= r; x++) {
      dp(ctx, x, py + 2 + i, x === l ? PBL : x === r ? PBD : PB);
    }
  });

  // Base
  for (let x = 5; x <= 16; x++) dp(ctx, x, py + 8, PA);
  for (let x = 6; x <= 15; x++) dp(ctx, x, py + 9, PAD);

  // Shadow
  for (let x = 5; x <= 16; x++) dp(ctx, x, py + 10, '#000000', 0.35);
  for (let x = 7; x <= 14; x++) dp(ctx, x, py + 11, '#000000', 0.15);
};

// ── Sunflower ─────────────────────────────────────────────────
const drawSunflower = (ctx: CanvasRenderingContext2D, stage: number, t: number) => {
  if (stage === 0) return;
  const maxH = [0, 2, 5, 9, 12];
  const prevH = maxH[Math.max(0, stage - 1)];
  const h = Math.round(prevH + (maxH[stage] - prevH) * t);

  // Stem
  for (let i = 0; i < h; i++) {
    dp(ctx, CX, BASE_Y - i, i % 2 === 0 ? SG : SGD);
  }

  // Stage 2+: lower leaves
  if (stage >= 2 && h >= 4) {
    dp(ctx, CX - 1, BASE_Y - 2, LG);  dp(ctx, CX - 2, BASE_Y - 1, LGL);
    dp(ctx, CX + 1, BASE_Y - 3, LG);  dp(ctx, CX + 2, BASE_Y - 2, LGL);
    dp(ctx, CX - 1, BASE_Y - 4, LG);  dp(ctx, CX + 1, BASE_Y - 5, LG);
  }

  // Stage 3+: upper leaves
  if (stage >= 3 && h >= 7) {
    dp(ctx, CX - 1, BASE_Y - 6, LG); dp(ctx, CX - 2, BASE_Y - 5, LG); dp(ctx, CX - 3, BASE_Y - 5, LGL);
    dp(ctx, CX + 1, BASE_Y - 7, LG); dp(ctx, CX + 2, BASE_Y - 6, LG); dp(ctx, CX + 3, BASE_Y - 6, LGL);
  }

  // Stage 4: flower head
  if (stage >= 4 && h >= 10) {
    const hy = BASE_Y - h - 2;
    // Petals
    for (let dx = -3; dx <= 3; dx++) {
      dp(ctx, CX + dx, hy - 1, PY);
      dp(ctx, CX + dx, hy + 5, PY);
    }
    for (let dy = 0; dy <= 4; dy++) {
      dp(ctx, CX - 4, hy + dy, PY);
      dp(ctx, CX + 4, hy + dy, PY);
    }
    // Disc center (5×5)
    for (let dx = -2; dx <= 2; dx++) {
      for (let dy = 0; dy <= 4; dy++) {
        const edge = Math.abs(dx) === 2 || dy === 0 || dy === 4;
        const highlight = Math.abs(dx) <= 1 && dy >= 1 && dy <= 3;
        dp(ctx, CX + dx, hy + dy, edge ? PYD : highlight ? FCL : FC);
      }
    }
  }
};

// ── Cactus ────────────────────────────────────────────────────
const drawCactus = (ctx: CanvasRenderingContext2D, stage: number, t: number) => {
  if (stage === 0) return;
  const maxH = [0, 3, 7, 11, 15];
  const prevH = maxH[Math.max(0, stage - 1)];
  const h = Math.round(prevH + (maxH[stage] - prevH) * t);

  // Main trunk (3 wide)
  for (let i = 0; i < h; i++) {
    const y = BASE_Y - i;
    dp(ctx, CX - 1, y, CG);
    dp(ctx, CX,     y, CGL);
    dp(ctx, CX + 1, y, CGD);
  }

  // Spikes along trunk
  if (stage >= 2 && h >= 4) {
    [1, 3, 5, 7, 9].forEach(i => {
      if (i < h - 1) {
        dp(ctx, CX - 2, BASE_Y - i, CSP);
        dp(ctx, CX + 2, BASE_Y - i, CSP);
      }
    });
  }

  // Left arm (stage 3+)
  if (stage >= 3 && h >= 9) {
    const armY = BASE_Y - 7;
    for (let i = 2; i <= 4; i++) dp(ctx, CX - i, armY, CG);
    for (let i = 0; i <= 3; i++) dp(ctx, CX - 5, armY - i, i === 0 ? CGD : i === 3 ? CGL : CG);
    dp(ctx, CX - 6, armY - 1, CSP); dp(ctx, CX - 6, armY - 2, CSP);
  }

  // Right arm (stage 4+)
  if (stage >= 4 && h >= 13) {
    const armY = BASE_Y - 10;
    for (let i = 2; i <= 4; i++) dp(ctx, CX + i, armY, CG);
    for (let i = 0; i <= 3; i++) dp(ctx, CX + 5, armY - i, i === 0 ? CGD : i === 3 ? CGL : CG);
    dp(ctx, CX + 6, armY - 1, CSP); dp(ctx, CX + 6, armY - 2, CSP);
  }
};

// ── Mushroom ──────────────────────────────────────────────────
const drawMushroom = (ctx: CanvasRenderingContext2D, stage: number, t: number) => {
  if (stage === 0) return;
  const maxH = [0, 2, 4, 6, 8];
  const prevH = maxH[Math.max(0, stage - 1)];
  const h = Math.round(prevH + (maxH[stage] - prevH) * t);

  // Stem
  for (let i = 0; i < h; i++) {
    const y = BASE_Y - i;
    dp(ctx, CX - 1, y, MSTD); dp(ctx, CX, y, MST); dp(ctx, CX + 1, y, MSTD);
  }
  if (h > 0) {
    dp(ctx, CX - 2, BASE_Y, MSTD); dp(ctx, CX + 2, BASE_Y, MSTD);
  }
  if (stage === 1) return;

  const capY = BASE_Y - h;

  if (stage === 2) {
    [CX - 1, CX, CX + 1].forEach(x => dp(ctx, x, capY - 1, x === CX ? MRH : MRD));
    [-3,-2,-1,0,1,2,3].map(dx => CX + dx).forEach(x => dp(ctx, x, capY, x === CX ? MRH : MR));
    dp(ctx, CX + 1, capY - 1, MSP);
  }

  if (stage === 3) {
    [-2,-1,0,1,2].map(dx => CX + dx).forEach(x => dp(ctx, x, capY - 3, x === CX ? MRH : MRD));
    [-4,-3,-2,-1,0,1,2,3,4].map(dx => CX + dx).forEach(x => dp(ctx, x, capY - 2, x === CX || x === CX+1 ? MRH : x === CX-4||x===CX+4 ? MRD : MR));
    [-5,-4,-3,-2,-1,0,1,2,3,4,5].map(dx => CX + dx).forEach(x => dp(ctx, x, capY - 1, x===CX-5||x===CX+5 ? MRD : MR));
    [-4,-3,-2,-1,0,1,2,3,4].map(dx => CX + dx).forEach(x => dp(ctx, x, capY, MRD));
    dp(ctx, CX - 2, capY - 2, MSP); dp(ctx, CX - 1, capY - 2, MSP);
    dp(ctx, CX + 2, capY - 2, MSP); dp(ctx, CX + 3, capY - 2, MSP);
    dp(ctx, CX - 1, capY - 1, MSP);
  }

  if (stage === 4) {
    const rows = [
      [-1,0,1,2].map(dx => CX + dx),
      [-4,-3,-2,-1,0,1,2,3,4,5].map(dx => CX + dx),
      [-6,-5,-4,-3,-2,-1,0,1,2,3,4,5,6].map(dx => CX + dx),
      [-7,-6,-5,-4,-3,-2,-1,0,1,2,3,4,5,6,7].map(dx => CX + dx),
      [-7,-6,-5,-4,-3,-2,-1,0,1,2,3,4,5,6,7].map(dx => CX + dx),
      [-6,-5,-4,-3,-2,-1,0,1,2,3,4,5,6].map(dx => CX + dx),
    ];
    rows.forEach((row, dy) => {
      row.forEach(x => {
        const edge = x === row[0] || x === row[row.length - 1];
        const hi = (x === CX || x === CX + 1) && dy <= 1;
        dp(ctx, x, capY - 5 + dy, edge || dy === 0 ? MRD : hi ? MRH : MR);
      });
    });
    // Spots
    [[CX-3,capY-4],[CX-2,capY-4],[CX+2,capY-3],[CX+3,capY-3],
     [CX-5,capY-2],[CX-4,capY-2],[CX+4,capY-1],[CX+5,capY-1],
     [CX-1,capY-1],[CX,capY-1]].forEach(([x,y]) => dp(ctx, x, y, MSP));
  }
};

// ── Potato ────────────────────────────────────────────────────
const drawPotato = (ctx: CanvasRenderingContext2D, stage: number, t: number) => {
  if (stage === 0) return;

  if (stage >= 1) {
    dp(ctx, CX, BASE_Y, SG); dp(ctx, CX, BASE_Y - 1, LGL);
    if (stage >= 2 || t > 0.4) {
      dp(ctx, CX - 2, BASE_Y, SG); dp(ctx, CX - 2, BASE_Y - 1, LG);
      dp(ctx, CX + 2, BASE_Y, SG); dp(ctx, CX + 2, BASE_Y - 1, LG);
    }
  }

  if (stage >= 2) {
    for (let i = 0; i < 5; i++) dp(ctx, CX, BASE_Y - i, i === 0 ? SGD : SG);
    for (let i = 0; i < 4; i++) dp(ctx, CX - 3, BASE_Y - i, SG);
    for (let i = 0; i < 4; i++) dp(ctx, CX + 3, BASE_Y - i, SG);
    dp(ctx, CX, BASE_Y - 5, LGL);
    dp(ctx, CX - 4, BASE_Y - 2, LG); dp(ctx, CX - 5, BASE_Y - 1, LGL);
    dp(ctx, CX + 4, BASE_Y - 2, LG); dp(ctx, CX + 5, BASE_Y - 1, LGL);
    dp(ctx, CX - 2, BASE_Y - 4, LG); dp(ctx, CX + 2, BASE_Y - 4, LG);
  }

  if (stage >= 3) {
    for (let i = 4; i < 9; i++) dp(ctx, CX, BASE_Y - i, SG);
    dp(ctx, CX - 1, BASE_Y - 6, LG); dp(ctx, CX - 2, BASE_Y - 7, LG); dp(ctx, CX - 3, BASE_Y - 6, LGL);
    dp(ctx, CX + 1, BASE_Y - 7, LG); dp(ctx, CX + 2, BASE_Y - 8, LG); dp(ctx, CX + 3, BASE_Y - 7, LGL);
    dp(ctx, CX, BASE_Y - 9, LGL);
    dp(ctx, CX - 2, BASE_Y - 5, LG); dp(ctx, CX + 2, BASE_Y - 5, LG);
  }

  if (stage >= 4) {
    for (let i = 8; i < 13; i++) dp(ctx, CX, BASE_Y - i, SG);
    dp(ctx, CX - 1, BASE_Y - 10, LG); dp(ctx, CX, BASE_Y - 12, LGL); dp(ctx, CX + 1, BASE_Y - 10, LG);
    dp(ctx, CX - 3, BASE_Y - 9, LGL); dp(ctx, CX + 3, BASE_Y - 9, LGL);
    dp(ctx, CX - 2, BASE_Y - 11, LG); dp(ctx, CX + 2, BASE_Y - 11, LG);
    // Potatoes in soil
    dp(ctx, CX - 4, SOIL_TOP + 1, P2Y);  dp(ctx, CX - 5, SOIL_TOP + 1, P2Y);
    dp(ctx, CX - 4, SOIL_TOP + 2, P2YD);
    dp(ctx, CX + 4, SOIL_TOP + 1, P2Y);  dp(ctx, CX + 5, SOIL_TOP + 1, P2Y);
    dp(ctx, CX + 4, SOIL_TOP + 2, P2YD);
    dp(ctx, CX,     SOIL_TOP + 2, P2Y);  dp(ctx, CX + 1, SOIL_TOP + 2, P2Y);
    dp(ctx, CX - 1, SOIL_TOP + 3, P2YD); dp(ctx, CX + 2, SOIL_TOP + 3, P2YD);
  }
};

// ── Flower ────────────────────────────────────────────────────
const drawFlower = (ctx: CanvasRenderingContext2D, stage: number, t: number) => {
  if (stage === 0) return;
  const maxH = [0, 2, 5, 9, 12];
  const prevH = maxH[Math.max(0, stage - 1)];
  const h = Math.round(prevH + (maxH[stage] - prevH) * t);

  for (let i = 0; i < h; i++) dp(ctx, CX, BASE_Y - i, SG);

  if (stage >= 2 && h >= 3) {
    dp(ctx, CX - 1, BASE_Y - 2, LG); dp(ctx, CX - 2, BASE_Y - 1, LGL);
    dp(ctx, CX + 1, BASE_Y - 3, LG); dp(ctx, CX + 2, BASE_Y - 2, LGL);
  }

  if (stage >= 3 && h >= 7) {
    dp(ctx, CX - 1, BASE_Y - 6, LG); dp(ctx, CX - 2, BASE_Y - 5, LG);
    dp(ctx, CX + 1, BASE_Y - 7, LG); dp(ctx, CX + 2, BASE_Y - 6, LG);
    // Bud
    dp(ctx, CX, BASE_Y - h, FP1);
    dp(ctx, CX - 1, BASE_Y - h + 1, FP1);
    dp(ctx, CX + 1, BASE_Y - h + 1, FP1);
  }

  if (stage >= 4 && h >= 10) {
    const fy = BASE_Y - h - 2;
    // Petals
    dp(ctx, CX - 1, fy - 2, FP1); dp(ctx, CX, fy - 2, FP2); dp(ctx, CX + 1, fy - 2, FP1);
    dp(ctx, CX - 2, fy - 3, FP1); dp(ctx, CX + 2, fy - 3, FP1);
    [-1,0,1].forEach(dy => {
      dp(ctx, CX - 3, fy + dy, FP1); dp(ctx, CX + 3, fy + dy, FP1);
    });
    dp(ctx, CX - 1, fy + 3, FP1); dp(ctx, CX, fy + 3, FP2); dp(ctx, CX + 1, fy + 3, FP1);
    dp(ctx, CX - 2, fy + 4, FP1); dp(ctx, CX + 2, fy + 4, FP1);
    // Center (3×3)
    for (let dx = -1; dx <= 1; dx++) {
      for (let dy = -1; dy <= 1; dy++) {
        dp(ctx, CX + dx, fy + dy, FCE);
      }
    }
  }
};

// ── Plant dispatcher ──────────────────────────────────────────
const drawPlant = (ctx: CanvasRenderingContext2D, type: PT, stage: number, t: number) => {
  switch (type) {
    case 'sunflower': drawSunflower(ctx, stage, t); break;
    case 'cactus':    drawCactus(ctx, stage, t);    break;
    case 'mushroom':  drawMushroom(ctx, stage, t);  break;
    case 'potato':    drawPotato(ctx, stage, t);    break;
    case 'flower':    drawFlower(ctx, stage, t);    break;
  }
};

// ── Main App ──────────────────────────────────────────────────
export default function App() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const rafRef = useRef<number>(0);
  const stateRef = useRef({ planted: false, plantedAt: 0, plant: 'sunflower' as PT, growthTime: 3000 });
  const lastUIRef = useRef(0);

  const [selected, setSelected] = useState<PT>('sunflower');
  const [planted, setPlanted] = useState(false);
  const [uiStage, setUiStage] = useState(0);
  const [uiProgress, setUiProgress] = useState(0);

  const render = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d')!;
    ctx.imageSmoothingEnabled = false;

    const st = stateRef.current;
    const now = Date.now();
    let stage = 0, t = 0;

    if (st.planted) {
      const elapsed = now - st.plantedAt;
      const raw = elapsed / st.growthTime;
      stage = Math.min(4, Math.floor(raw) + 1);
      t = raw % 1;
      if (stage >= 4) { stage = 4; t = 1; }

      if (now - lastUIRef.current > 120) {
        lastUIRef.current = now;
        setUiStage(stage);
        setUiProgress(stage < 4 ? t : 1);
      }
    }

    ctx.clearRect(0, 0, GW * S, GH * S);
    drawBG(ctx, now);
    drawSoil(ctx);
    drawPlant(ctx, st.plant, stage, t);
    drawPot(ctx);

    rafRef.current = requestAnimationFrame(render);
  }, []);

  useEffect(() => {
    rafRef.current = requestAnimationFrame(render);
    return () => cancelAnimationFrame(rafRef.current);
  }, [render]);

  const handlePlant = () => {
    const info = PLANTS.find(p => p.id === selected)!;
    stateRef.current = { planted: true, plantedAt: Date.now(), plant: selected, growthTime: info.growthTime };
    setPlanted(true);
    setUiStage(1);
    setUiProgress(0);
  };

  const handleReset = () => {
    stateRef.current.planted = false;
    setPlanted(false);
    setUiStage(0);
    setUiProgress(0);
  };

  const selInfo = PLANTS.find(p => p.id === selected)!;

  const pixelFont: React.CSSProperties = { fontFamily: "'Press Start 2P', monospace" };

  return (
    <div
      className="min-h-screen flex flex-col items-center justify-center gap-5 p-6"
      style={{ background: 'linear-gradient(180deg, #0A0A18 0%, #111128 100%)', ...pixelFont }}
    >
      {/* Title */}
      <h1 style={{ fontSize: '16px', color: '#F4C830', textShadow: '3px 3px #7A3808', letterSpacing: '2px' }}>
        🌱 PIXEL GARDEN
      </h1>

      {/* Canvas */}
      <div style={{
        border: '4px solid #2A2040',
        boxShadow: '0 0 24px #4040A040, inset 0 0 12px #00000080',
        background: '#080810',
        padding: '4px',
      }}>
        <canvas
          ref={canvasRef}
          width={GW * S}
          height={GH * S}
          style={{ display: 'block', imageRendering: 'pixelated' }}
        />
      </div>

      {/* Stage / progress */}
      <div style={{ width: `${GW * S}px`, textAlign: 'center' }}>
        {planted ? (
          <>
            <p style={{ fontSize: '8px', color: uiStage >= 4 ? '#70D050' : '#A0C8E0', marginBottom: '8px', letterSpacing: '1px' }}>
              {STAGE_NAMES[uiStage]}
            </p>
            {uiStage < 4 && (
              <div style={{ height: '10px', background: '#1A1A3A', border: '2px solid #2A2A50', position: 'relative', overflow: 'hidden' }}>
                <div style={{
                  width: `${uiProgress * 100}%`,
                  height: '100%',
                  background: `linear-gradient(90deg, #2D8B1E, #70D050)`,
                  transition: 'width 0.12s linear',
                  boxShadow: '0 0 6px #70D05080',
                }} />
                {/* Pixel grid on bar */}
                {Array.from({ length: 4 }).map((_, i) => (
                  <div key={i} style={{
                    position: 'absolute', top: 0, left: `${(i + 1) * 25}%`,
                    width: '2px', height: '100%', background: '#1A1A3A50',
                  }} />
                ))}
              </div>
            )}
          </>
        ) : (
          <p style={{ fontSize: '7px', color: '#505080', letterSpacing: '1px' }}>SELECT A PLANT TO BEGIN</p>
        )}
      </div>

      {/* Plant selection */}
      {!planted && (
        <div className="flex flex-col items-center gap-3">
          <div className="flex gap-2">
            {PLANTS.map(p => (
              <button
                key={p.id}
                onClick={() => setSelected(p.id)}
                style={{
                  padding: '10px',
                  border: `3px solid ${selected === p.id ? p.color : '#2A2A50'}`,
                  background: selected === p.id ? `${p.color}22` : '#12122A',
                  cursor: 'pointer',
                  fontSize: '26px',
                  lineHeight: 1,
                  borderRadius: '4px',
                  boxShadow: selected === p.id ? `0 0 10px ${p.color}66` : 'none',
                  transition: 'all 0.1s',
                  transform: selected === p.id ? 'scale(1.1)' : 'scale(1)',
                }}
              >
                {p.emoji}
              </button>
            ))}
          </div>
          <p style={{ fontSize: '7px', color: selInfo.color, letterSpacing: '1px', textShadow: `0 0 8px ${selInfo.color}` }}>
            {selInfo.name.toUpperCase()}
          </p>
        </div>
      )}

      {/* Action button */}
      <button
        onClick={planted ? handleReset : handlePlant}
        style={{
          padding: '12px 28px',
          background: planted ? '#2A0A0A' : '#0A2A0A',
          border: `3px solid ${planted ? '#A02020' : '#20A020'}`,
          color: planted ? '#F04040' : '#40F040',
          cursor: 'pointer',
          fontSize: '9px',
          ...pixelFont,
          borderRadius: '4px',
          boxShadow: planted ? '0 0 10px #A0202040' : '0 0 10px #20A02040',
          letterSpacing: '1px',
          transition: 'all 0.1s',
        }}
        onMouseEnter={e => { (e.target as HTMLElement).style.transform = 'scale(1.05)'; }}
        onMouseLeave={e => { (e.target as HTMLElement).style.transform = 'scale(1)'; }}
      >
        {planted ? '↺  RESET' : '▶  PLANT SEED'}
      </button>

      {/* Growth time hint */}
      {!planted && (
        <p style={{ fontSize: '6px', color: '#303060', letterSpacing: '1px' }}>
          GROWTH TIME: {selInfo.growthTime / 1000}s PER STAGE
        </p>
      )}
    </div>
  );
}
